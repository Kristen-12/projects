import sqlite3
from tkinter import messagebox
def check_low_stock():
    conn = sqlite3.connect('pos_systems.db')
    cursor = conn.cursor()

    # Query to find products with low stock
    cursor.execute("SELECT name, stock FROM products WHERE stock < 5")
    low_stock = cursor.fetchall()
    conn.close()

    if low_stock:
        warning_message = "The following products are low on stock:\n"
        for product in low_stock:
            warning_message += f"- {product[0]}: {product[1]} units left\n"
        messagebox.showwarning("Low Stock Warning", warning_message)
