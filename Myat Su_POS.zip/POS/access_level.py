import sqlite3
class Access:
    def __init__(self):

        self.admin = {
            "admin": "admin123"
        }

    def authenticate(self, username, password):
        if username in self.admin and self.admin[username]== password:
            return "Admin"
        conn = sqlite3.connect('pos_systems.db')
        cursor = conn.cursor()
        cursor.execute("SELECT role FROM signup WHERE username = ? AND password = ?", (username, password))
        result = cursor.fetchone()
        conn.close()

        if result:
            return result[0]
        return None

    def register_staff(self, username, password):
        conn = sqlite3.connect('pos_systems.db')
        cursor = conn.cursor()

        cursor.execute("SELECT username FROM signup WHERE username=?", (username,))
        if cursor.fetchone():
            raise ValueError("Username already exists!")
        cursor.execute("INSERT INTO signup( username, password,role) VALUES (?, ?, ?)",(username, password,"Staff"))
        conn.commit()
        conn.close()