import sqlite3

def create_db():
    conn = sqlite3.connect('pos_systems.db')
    cursor = conn.cursor()

    # Create products, customers, and sales tables
    cursor.execute('''CREATE TABLE IF NOT EXISTS products (
                        id INTEGER PRIMARY KEY,
                        name TEXT,
                        price REAL,
                        stock INTEGER)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
                        id INTEGER PRIMARY KEY,
                        name TEXT,
                        phone TEXT)''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS signup (
                    id INTEGER PRIMARY KEY,
                    username TEXT,
                    password TEXT,
                    role TEXT DEFAULT 'Staff')''')


    cursor.execute('''CREATE TABLE IF NOT EXISTS sales (
                        id INTEGER PRIMARY KEY,
                        product_id INTEGER,
                        quantity INTEGER,
                        total REAL,
                        date TEXT,
                        customer_id INTEGER,
                        FOREIGN KEY (product_id) REFERENCES products(id),
                        FOREIGN KEY (customer_id) REFERENCES customers(id))''')

    conn.commit()
    conn.close()

# Create the database when the program starts
create_db()
