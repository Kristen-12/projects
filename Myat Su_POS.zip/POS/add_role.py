import sqlite3

def add_role_column():
    conn = sqlite3.connect('pos_systems.db')
    cursor = conn.cursor()
    
    # Add the 'role' column to the 'signup' table if it doesn't already exist
    cursor.execute("ALTER TABLE signup ADD COLUMN role TEXT DEFAULT 'Staff'")
    
    conn.commit()
    conn.close()

add_role_column()