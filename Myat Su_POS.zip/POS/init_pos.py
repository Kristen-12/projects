from tkinter import *
import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
from product_management import add_product,update_product,remove_product
from generate_sale_report import generate_sales_report
from sale_processing import process_sale
from setDatabase import create_db
from access_level import Access
from low_stock import check_low_stock



# Main GUI application
class POSApp:
    
    def __init__(self, root,role):
        self.root = root
        self.role = role
        self.root.title("POS System")
        self.root.geometry("600x400")
        create_db()

        self.bg_image = tk.PhotoImage(file="D:\Advanced Programming\wrld.png") 
        self.background_label = tk.Label(root, image=self.bg_image)
        self.background_label.place(relwidth=1, relheight=1)

        self.setup_menu()

    def setup_menu(self):
        menu_bar = Menu(self.root)
        self.root.config(menu=menu_bar)

        # Product Menu (Admin only)
        if self.role == "Admin":
            product_menu = Menu(menu_bar, tearoff=0)
            menu_bar.add_cascade(label="Product", menu=product_menu)
            product_menu.add_command(label="Add Product", command=self.add_product_gui)
            product_menu.add_command(label="Update Product", command=self.update_product_gui)
            product_menu.add_command(label="Remove Product", command=self.remove_product_gui)
            product_menu.add_command(label="Show Product", command=self.show_product_gui)

        # Sale Menu 
        sale_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Sale", menu=sale_menu)
        sale_menu.add_command(label="Process Sale", command=self.process_sale_gui)

        # Report Menu 
        report_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Report", menu=report_menu)
        report_menu.add_command(label="Generate Sales Report", command=self.show_sales_report)

        # Disable 
        if self.role == "Staff":
            menu_bar.entryconfig("Product", state="disabled")
#adding a product.
    def add_product_gui(self):
        def add_product_to_db():
            name = name_entry.get()
            price = price_entry.get()
            stock = stock_entry.get()
            if not name or not price or not stock:
                messagebox.showerror("Error", "Please enter all fields")
                return
            try:
                add_product(name, float(price), int(stock))
                messagebox.showinfo("Success", "Product added successfully!")
                add_product_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add product: {e}")

        add_product_window = Toplevel(self.root)
        add_product_window.title("Add Product")
        add_product_window.geometry("400x300")

        Label(add_product_window, text="Product Name:").grid(row=0, column=0, padx=10, pady=10, sticky=E)
        name_entry = Entry(add_product_window, width=30)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        Label(add_product_window, text="Price:").grid(row=1, column=0, padx=10, pady=10, sticky=E)
        price_entry = Entry(add_product_window, width=30)
        price_entry.grid(row=1, column=1, padx=10, pady=10)

        Label(add_product_window, text="Stock:").grid(row=2, column=0, padx=10, pady=10, sticky=E)
        stock_entry = Entry(add_product_window, width=30)
        stock_entry.grid(row=2, column=1, padx=10, pady=10)

        Button(add_product_window, text="Add Product", command=add_product_to_db, bg="#FFA500", fg="white").grid(
            row=3, column=1, pady=20)
#update product
    def update_product_gui(self):
        def update_product_to_db():
            product_id = product_id_entry.get()
            name = name_entry.get()
            price = price_entry.get()
            stock = stock_entry.get()
            if not product_id or not name or not price or not stock:
                messagebox.showerror("Error", "All fields are required!")
                return
            try:
                update_product(int(product_id), name, float(price), int(stock))
                messagebox.showinfo("Success", f"Product with ID {product_id} updated successfully!")
                update_product_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update product: {e}")

        update_product_window = Toplevel(self.root)
        update_product_window.title("Update Product")
        update_product_window.geometry("400x300")

        Label(update_product_window, text="Product ID:").grid(row=0, column=0, padx=10, pady=10, sticky=E)
        product_id_entry = Entry(update_product_window, width=30)
        product_id_entry.grid(row=0, column=1, padx=10, pady=10)

        Label(update_product_window, text="New Name:").grid(row=1, column=0, padx=10, pady=10, sticky=E)
        name_entry = Entry(update_product_window, width=30)
        name_entry.grid(row=1, column=1, padx=10, pady=10)

        Label(update_product_window, text="New Price:").grid(row=2, column=0, padx=10, pady=10, sticky=E)
        price_entry = Entry(update_product_window, width=30)
        price_entry.grid(row=2, column=1, padx=10, pady=10)

        Label(update_product_window, text="New Stock:").grid(row=3, column=0, padx=10, pady=10, sticky=E)
        stock_entry = Entry(update_product_window, width=30)
        stock_entry.grid(row=3, column=1, padx=10, pady=10)

        Button(update_product_window, text="Update Product", command=update_product_to_db, bg="#FFA500", fg="white").grid(
            row=4, column=1, pady=20)

#show product
    def show_product_gui(self):
        def show_product():

            conn = sqlite3.connect('pos_systems.db')
            c = conn.cursor()
            
            #query the database
            c.execute("SELECT *, oid FROM products")
            records = c.fetchall()
            print(records)
        #loop through result
            print_records = ''
            for record in records:
                print_records += str(record[0])+"."+ str(record[1])+" "+str(record[2])+ " "+"\t"+"\t"+str(record[3])+"\n"
        
            product_text_area.delete("1.0", END)
            product_text_area.insert(END, print_records)

        #show_product_window`
        show_product_window = Toplevel(self.root)
        show_product_window.title("Show Products")
        show_product_window.geometry("500x400")

        # product information
        product_text_area = Text(show_product_window, width=60, height=20, wrap=WORD)
        product_text_area.pack(pady=10)

        #  display of products
        Button(show_product_window, text="Show Products", command=show_product,bg="#FFA500", fg="white").pack()
#sale process
    def process_sale_gui(self):
        def process_sale_button():
            product_id = product_id_entry.get()
            quantity = quantity_entry.get()
            if not product_id or not quantity:
                messagebox.showerror("Error", "Both are required!")
                return
            try:
                result = process_sale(int(product_id), int(quantity))
                messagebox.showinfo("Success", result)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to process sale: {e}")

        sale_window = Toplevel(self.root)
        sale_window.title("Process Sale")
        sale_window.geometry("400x200")

        Label(sale_window, text="Product ID:").grid(row=0, column=0, padx=10, pady=10, sticky=E)
        product_id_entry = Entry(sale_window, width=30)
        product_id_entry.grid(row=0, column=1, padx=10, pady=10)

        Label(sale_window, text="Quantity:").grid(row=1, column=0, padx=10, pady=10, sticky=E)
        quantity_entry = Entry(sale_window, width=30)
        quantity_entry.grid(row=1, column=1, padx=10, pady=10)

        Button(sale_window, text="Process Sale", command=process_sale_button, bg="#FFA500", fg="white").grid(row=2, column=1, pady=20)

    def remove_product_gui(self):

        def remove_product_from_db():
            product_id = int(id_entry.get())
            remove_product(product_id)
            messagebox.showinfo("Success", f"Product with ID {product_id} removed successfully!")
            remove_product_window.destroy()

        remove_product_window = Toplevel(self.root)
        remove_product_window.title("Remove Product")
        remove_product_window.geometry("300x200")

        Label(remove_product_window, text="Product ID:").grid(row=0, column=0, padx=10, pady=10, sticky=E)
        id_entry = Entry(remove_product_window, width=30)
        id_entry.grid(row=0, column=1, padx=10, pady=10)

        Button(remove_product_window, text="Remove Product", command=remove_product_from_db, bg="#FFA500", fg="white").grid(row=1, column=1, pady=20)

    def show_sales_report(self):

        report = generate_sales_report()
        report_window = Toplevel(self.root)
        report_window.title("Sales Report")
        text_area = Text(report_window, width=80, height=20)
        text_area.pack()
        text_area.insert(END, report)


if __name__ == "__main__":
    root = Tk()
    root.geometry("300x200")
#login
    root.title("POS system")

    def login():
        username = username_entry.get()
        password = password_entry.get()
        access = Access()
        role = access.authenticate(username, password)
       

        if role:
            login_window.destroy()
            POSApp(root, role)

            if role == "Admin":
                check_low_stock()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")
    #signup
    def signup():
        def signup_staff():
            username = username_entry.get()
            password = password_entry.get()

            if not username or not password:  # Check if either field is empty
                messagebox.showerror("Error", "Both username and password are required!")
                return

            try:
                access = Access()
                access.register_staff(username, password)
                messagebox.showinfo("Success", "Staff account has created successfully!")
                signup_window.destroy()
            except ValueError as e:
                messagebox.showerror("Error", str(e))

        signup_window = Toplevel(root)
        signup_window.title("Signup")
        signup_window.geometry("300x300")

        Label(signup_window, text="Username:").grid(row=0, column=0, padx=10, pady=5)
        username_entry = Entry(signup_window, width=30)
        username_entry.grid(row=0, column=1, padx=10, pady=5)

        Label(signup_window, text="Password:").grid(row=1, column=0, padx=10, pady=5)
        password_entry = Entry(signup_window, width=30, show="*")
        password_entry.grid(row=1, column=1, padx=10, pady=5)

        Button(signup_window, text="Register", command=signup_staff,width=25, fg="white", bg="#007FFF").grid(row=3, column=1, padx=5)

    login_window = Toplevel(root)
    login_window.title("Login")
    login_window.geometry("320x220")

    # Username entry
    Label(login_window, text="Username:").grid(row=0, column=0, padx=10, pady=5)
    username_entry = Entry(login_window, width=30)
    username_entry.grid(row=0, column=1, padx=10, pady=5)

    # Password entry
    Label(login_window, text="Password:").grid(row=1, column=0, padx=10, pady=5)
    password_entry = Entry(login_window, width=30, show="*")
    password_entry.grid(row=1, column=1, padx=10, pady=5)
    
    Button(login_window, text="Login", command=login, bg="#2196F3", fg="white", width=15).grid(row=2, column=0, pady=20)
    Button(login_window, text="Signup", command=signup, bg="#FFA500", fg="white", width=15).grid(row=2, column=1, pady=20)


    root.mainloop()